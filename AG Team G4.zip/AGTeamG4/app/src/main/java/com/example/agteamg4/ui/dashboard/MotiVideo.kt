package com.example.agteamg4.ui.dashboard

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.agteamg4.MainActivity
import com.example.agteamg4.R
import com.example.agteamg4.databinding.ActivityMotiVideoBinding
import com.example.agteamg4.ui.Registration.RegistrationActivity
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class MotiVideo : AppCompatActivity() {

    lateinit var firebaseDatabase: FirebaseDatabase
    lateinit var database: DatabaseReference

    lateinit var binding: ActivityMotiVideoBinding

    override fun onCreate(savedInstanceState: Bundle?) {

        firebaseDatabase = FirebaseDatabase.getInstance()
        database = firebaseDatabase.reference

        binding = ActivityMotiVideoBinding.inflate(layoutInflater)

        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        binding.page1Nextbtn.setOnClickListener {
            val intent = Intent(this@MotiVideo, RegistrationActivity::class.java)
            startActivity(intent)
            finish()
        }

        binding.apply {

            qwerty.setOnClickListener {
                database.child("motivationPart").child("link").get().addOnSuccessListener {

                    val videoLink = it.value

                    binding.motivideo.setVideoPath(videoLink.toString())
                    val mediaController = android.widget.MediaController(this@MotiVideo)
                    mediaController.setAnchorView(binding.motivideo)
                    binding.motivideo.setMediaController(mediaController)
                    binding.motivideo.start()



                }
            }


        }


    }
}