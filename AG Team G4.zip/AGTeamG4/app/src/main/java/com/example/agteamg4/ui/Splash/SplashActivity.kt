package com.example.agteamg4.ui.Splash

import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.View
import androidx.navigation.findNavController
import com.example.agteamg4.Data.Users
import com.example.agteamg4.MainActivity
import com.example.agteamg4.R
import com.example.agteamg4.databinding.ActivityMainBinding
import com.example.agteamg4.databinding.ActivitySplashBinding
import com.example.agteamg4.ui.Registration.Reg2Activity
import com.example.agteamg4.ui.Registration.RegistrationActivity
import com.example.agteamg4.ui.dashboard.MotiVideo
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.getValue

class SplashActivity : AppCompatActivity() {

    lateinit var reference: DatabaseReference
    lateinit var reference1: DatabaseReference

    lateinit var firebaseDatabase: FirebaseDatabase
    override fun onCreate(savedInstanceState: Bundle?) {








        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        firebaseDatabase = FirebaseDatabase.getInstance()
        var auth = FirebaseAuth.getInstance()

        var users = ArrayList<Users>()
        reference = firebaseDatabase.getReference("users")


        reference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val value = dataSnapshot.children
                value.forEach {
                    users.add(it.getValue(Users::class.java)!!)
                }
                var isHave = false
                users.forEach {
                    if (it.id == "1") {
                            if (it.nickName!!.isNotBlank()) {
                                isHave = true
                                val handler = Handler(mainLooper)
                                handler.postDelayed({

                                    val intent =
                                        Intent(this@SplashActivity, MainActivity::class.java)

                                    startActivity(intent)
                                    finish()

                                }, 800)
                            }

                    }
                }


                if (!isHave) {
                    val handler = Handler(mainLooper)
                    handler.postDelayed({

                        val intent = Intent(this@SplashActivity, MotiVideo::class.java)

                        startActivity(intent)

                        finish()

                    }, 800)
                }
                Log.d(ContentValues.TAG, "Value is: $value")
            }

            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                Log.w(ContentValues.TAG, "Failed to read value.", error.toException())
            }
        })


//        Handler().postDelayed({
//            val mIntent = Intent(this@SplashActivity, RegistrationActivity::class.java)
//            startActivity(mIntent)
//            finish()
//        }, 2000)
    }
}