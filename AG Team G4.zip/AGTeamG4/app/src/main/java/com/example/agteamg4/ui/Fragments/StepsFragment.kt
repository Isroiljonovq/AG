package com.example.agteamg4.ui.Fragments

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.example.agteamg4.R
import com.example.agteamg4.databinding.FragmentStepsBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase


class StepsFragment : Fragment() {

    lateinit var binding: FragmentStepsBinding
    val database = Firebase.database.reference
    lateinit var firebaseAuth: FirebaseAuth


    var step1 = false
    var step2 = false
    var step3 = false
    var step4 = false
    var gender2 = false


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_steps, container, false)
        binding = FragmentStepsBinding.bind(view)
        firebaseAuth = FirebaseAuth.getInstance()
        val currenUser = firebaseAuth.currentUser


//        database.child("users").child(currenUser!!.uid).child("genderType").get()
//            .addOnSuccessListener {
//
//                Log.i("firebase", "Got value ${it.value}")
//                val text = it.value
//                if (text!!.equals("Female")){
//                    binding.stepBackground.setBackgroundResource(R.drawable.tlb_background_girl)
//                }
//
//
//            }


        val card1 = arguments?.getBoolean("card1")
        val card2 = arguments?.getBoolean("card2")
        val card3 = arguments?.getBoolean("card3")
        val card4 = arguments?.getBoolean("card4")
        val gender = arguments?.getBoolean("gender")



        if (card1 == true) {
            readItemData1()
        }
        if (card2 == true) {
            readItemData2()
        }
        if (card3 == true) {
            readItemData3()
        }
        if (card4 == true) {
            readItemData4()
        }
        if (gender == true) {
            binding.stepBackground.setBackgroundResource(R.drawable.tlb_background)
            gender2 = true
        }






        return view
    }

    fun readItemData1() {
        firebaseAuth = FirebaseAuth.getInstance()
        val currentUser = firebaseAuth.currentUser
        val database = Firebase.database.reference


        binding.cardView1.setOnClickListener {

            database.child("users").child("1").child("tasks").child("tyb")
                .child("2 week").get()
                .addOnSuccessListener {
                    val about = it.value
                    if (about == "true") {

                        Toast.makeText(
                            requireContext(),
                            "This task has already been completed",
                            Toast.LENGTH_SHORT
                        )
                            .show()

                    } else {


                        step1 = true
                        var bundle = Bundle().apply {
                            putBoolean("step1", step1)
                            putBoolean("gender", gender2)
                        }
                        findNavController().navigate(
                            R.id.action_stepsFragment_to_step2Fragment,
                            bundle
                        )
                    }
                }
        }


    }

    fun readItemData2() {
        firebaseAuth = FirebaseAuth.getInstance()
        val currentUser = firebaseAuth.currentUser
        val database = Firebase.database.reference
        binding.cardView1.setOnClickListener {
            database.child("users").child("1").child("tasks").child("cm")
                .child("2 week").get()
                .addOnSuccessListener {
                    val about = it.value
                    if (about == "true") {

                        Toast.makeText(
                            requireContext(),
                            "This task has already been completed",
                            Toast.LENGTH_SHORT
                        )
                            .show()

                    } else {


                        step2 = true
                        var bundle = Bundle().apply {
                            putBoolean("step2", step2)
                            putBoolean("gender", gender2)
                        }
                        findNavController().navigate(
                            R.id.action_stepsFragment_to_step2Fragment,
                            bundle
                        )
                    }
                }
        }
    }

    fun readItemData3() {
        firebaseAuth = FirebaseAuth.getInstance()
        val currentUser = firebaseAuth.currentUser
        val database = Firebase.database.reference
        binding.cardView1.setOnClickListener {
            database.child("users").child("1").child("tasks").child("english")
                .child("2 week").get()
                .addOnSuccessListener {
                    val about = it.value
                    if (about == "true") {

                        Toast.makeText(
                            requireContext(),
                            "This task has already been completed",
                            Toast.LENGTH_SHORT
                        )
                            .show()

                    } else {


                        step3 = true
                        var bundle = Bundle().apply {
                            putBoolean("step3", step3)
                            putBoolean("gender", gender2)
                        }
                        findNavController().navigate(
                            R.id.action_stepsFragment_to_step2Fragment,
                            bundle
                        )
                    }
                }
        }
    }

    fun readItemData4() {
        firebaseAuth = FirebaseAuth.getInstance()
        val currentUser = firebaseAuth.currentUser
        val database = Firebase.database.reference
        binding.cardView1.setOnClickListener {
            database.child("users").child("1").child("tasks").child("mathematics")
                .child("2 week").get()
                .addOnSuccessListener {
                    val about = it.value
                    if (about == "true") {

                        Toast.makeText(
                            requireContext(),
                            "This task has already been completed",
                            Toast.LENGTH_SHORT
                        )
                            .show()

                    } else {


                        step4 = true
                        var bundle = Bundle().apply {
                            putBoolean("step4", step4)
                            putBoolean("gender", gender2)
                        }
                        findNavController().navigate(
                            R.id.action_stepsFragment_to_step2Fragment,
                            bundle
                        )
                    }
                }
        }
    }
}