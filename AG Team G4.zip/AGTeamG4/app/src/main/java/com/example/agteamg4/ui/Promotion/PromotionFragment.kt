package com.example.agteamg4.ui.Promotion

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.example.agteamg4.R
import com.example.agteamg4.databinding.FragmentPromotionBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class PromotionFragment : Fragment() {

    lateinit var firebaseAuth: FirebaseAuth

    private var _binding: FragmentPromotionBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?


    ): View? {

        _binding = FragmentPromotionBinding.inflate(inflater, container, false)
        binding.apply {

            firebaseAuth = FirebaseAuth.getInstance()
            val currentUser = firebaseAuth.currentUser
            val database = Firebase.database.reference

            database.child("promotion").child("1").child("link").get()
                .addOnSuccessListener {
                    Log.i("firebase", "Got value ${it.value}")

                    val image = it.value


                    Glide.with(requireContext()).load(image).into(promo1)


                }
            database.child("promotion").child("1").child("text").get()
                .addOnSuccessListener {

                    val text = it.value


                    promoText.  text = text.toString()


                }


        }
        return binding.root
    }


}