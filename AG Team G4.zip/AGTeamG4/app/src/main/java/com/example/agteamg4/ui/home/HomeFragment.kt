package com.example.agteamg4.ui.home

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.example.agteamg4.R
import com.example.agteamg4.databinding.FragmentHomeBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class HomeFragment : Fragment() {

    private val database = Firebase.database.reference
    lateinit var firebaseAuth: FirebaseAuth


    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private var card1 = false
    private var card2 = false
    private var card3 = false
    private var card4 = false
    private var gender = false
    private var nickName = ""
    private var age = ""

    override fun onCreateView(

        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        firebaseAuth = FirebaseAuth.getInstance()
        val currenUser = firebaseAuth.currentUser
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root




        database.child("users").child("1").child("genderType").get()
            .addOnSuccessListener {

                Log.i("firebase", "Got value ${it.value}")
                val text = it.value
                if (text!! == "Female") {
                    binding.icon.setBackgroundResource(R.drawable.ag_girl)
                    binding.line.setBackgroundResource(R.color.blue)
                    gender = true
                } else {
                    binding.icon.setBackgroundResource(R.drawable.app_logo)
                    gender = false

                }


            }

        database.child("users").child("1").child("nickName").get()
            .addOnSuccessListener {
                val text = it.value
                nickName = text.toString()

            }
        database.child("users").child("1").child("age").get()
            .addOnSuccessListener {
                val text = it.value
                age = text.toString()

            }

        binding.info.setOnClickListener {
            val bundle = Bundle().apply {
                putBoolean("gender", gender)
                putString("nickName", nickName)
                putString("age", age)
            }
            findNavController().navigate(R.id.action_navigation_home_to_infoFragment, bundle)
        }

        getItemData()



        binding.card1.setOnClickListener {
            card1 = true
            val bundle = Bundle().apply {
                putBoolean("card1", card1)
                putBoolean("gender", gender)
            }
            findNavController().navigate(R.id.action_navigation_home_to_stepsFragment, bundle)
        }











        return root
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }


    fun getItemData() {


        database.child("ages").child("datas").child("tyb").child("picture").get()
            .addOnSuccessListener {
                Log.i("firebase", "Got value ${it.value}")
                val image = it.value

                Glide.with(this).load(image).into(binding.img1)

            }.addOnFailureListener {
                Log.e("firebase", "Error getting data", it)
            }



        database.child("ages").child("datas").child("cm").child("picture").get()
            .addOnSuccessListener {
                Log.i("firebase", "Got value ${it.value}")
                val image = it.value

                Glide.with(this).load(image).into(binding.img2)

            }.addOnFailureListener {
                Log.e("firebase", "Error getting data", it)
            }



        database.child("ages").child("datas").child("english").child("picture").get()
            .addOnSuccessListener {
                Log.i("firebase", "Got value ${it.value}")
                val image = it.value

                Glide.with(this).load(image).into(binding.img3)

            }.addOnFailureListener {
                Log.e("firebase", "Error getting data", it)
            }



        database.child("ages").child("datas").child("mathematics").child("picture").get()
            .addOnSuccessListener {
                Log.i("firebase", "Got value ${it.value}")
                val image = it.value

                Glide.with(this).load(image).into(binding.img4)

            }.addOnFailureListener {
                Log.e("firebase", "Error getting data", it)
            }



    }
}