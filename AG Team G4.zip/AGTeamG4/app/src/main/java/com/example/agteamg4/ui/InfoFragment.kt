package com.example.agteamg4.ui

import android.content.ContentValues
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.core.view.get
import androidx.navigation.fragment.findNavController
import com.example.agteamg4.Data.Users
import com.example.agteamg4.R
import com.example.agteamg4.databinding.FragmentInfoBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.getValue


class InfoFragment : Fragment() {

    private var _binding: FragmentInfoBinding? = null
    private val binding get() = _binding!!
    lateinit var firebaseAuth: FirebaseAuth
    lateinit var firebaseDatabase: FirebaseDatabase
    lateinit var reference: DatabaseReference
    lateinit var arrayAdapter1: ArrayAdapter<String>


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?


    ): View {

        firebaseAuth = FirebaseAuth.getInstance()
        val currenUser = firebaseAuth.currentUser

        firebaseDatabase = FirebaseDatabase.getInstance()
        reference = firebaseDatabase.getReference("users").child("1")
        _binding = FragmentInfoBinding.inflate(inflater, container, false)


        val gender = arguments?.getBoolean("gender")
        val nickName = arguments?.getString("nickName")
        val age = arguments?.getString("age")


        if (gender!!) {
            binding.icon.setBackgroundResource(R.drawable.ag_girl)
            binding.line.setBackgroundResource(R.color.blue)

        } else {
            binding.icon.setBackgroundResource(R.drawable.app_logo)

        }
        binding.nicknameTx.setText(nickName)
        binding.ageTx.setText(age)


        val spinner1 = arrayOf("Student", "Teacher", "Parent")
        arrayAdapter1 =
            ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, spinner1)
        binding.spinner1.adapter = arrayAdapter1




        binding.save.setOnClickListener {
            val name = binding.nicknameTx.text.toString()
            val age = binding.ageTx.text.toString()
            val roleType = binding.spinner1.selectedItem.toString()

            reference.child("nickName").setValue(name)
            reference.child("roleType").setValue(roleType)
            reference.child("age").setValue(age)

            findNavController().popBackStack()


        }







        return binding.root
    }


}
