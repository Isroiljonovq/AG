package com.example.agteamg4.Data

import android.text.Editable
import java.io.Serializable

data class Users(
    var id: String ?= null,
    var nickName: String?= null,
    var age: String? = null,
    var number: String?= null,
    var genderType: String?= null,
    var roleType: String?= null
) : Serializable