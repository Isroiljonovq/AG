package com.example.agteamg4.ui.Fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.example.agteamg4.R
import com.example.agteamg4.databinding.FragmentImageBinding
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase


class ImageFragment : Fragment() {
    lateinit var binding: FragmentImageBinding
    val database = Firebase.database.reference


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {


        val view = inflater.inflate(R.layout.fragment_image, container, false)
        binding = FragmentImageBinding.bind(view)



        when (arguments?.getString("image")) {
            "image1" ->
                database.child("ages").child("0-5").child("tyb").child("steps").child("1")
                    .child("1 week").child("1 task").child("1 image").get()
                    .addOnSuccessListener {
                        val about = it.value
                        Glide.with(this).load(about).transform(RotateTransformation(90f))
                            .into(binding.fullImage)

                        Toast.makeText(requireContext(), "1 image", Toast.LENGTH_SHORT).show()


                    }

            "image2" ->
                database.child("ages").child("0-5").child("tyb").child("steps").child("1")
                    .child("1 week").child("1 task").child("2 image").get().addOnSuccessListener {
                        val about = it.value
                        Toast.makeText(requireContext(), "2 image", Toast.LENGTH_SHORT).show()
                        Glide.with(this).load(about).transform(RotateTransformation(90f))
                            .into(binding.fullImage)
                    }

            "image3" ->
                database.child("ages").child("6-10").child("tyb").child("steps").child("1")
                    .child("1 week").child("1 task").child("1 image").get().addOnSuccessListener {
                        val about = it.value
                        Toast.makeText(requireContext(), "3 image", Toast.LENGTH_SHORT).show()

                        Glide.with(this).load(about).transform(RotateTransformation(90f))
                            .into(binding.fullImage)
                    }

            "image4" ->
                database.child("ages").child("6-10").child("tyb").child("steps").child("1")
                    .child("1 week").child("1 task").child("2 image").get().addOnSuccessListener {
                        val about = it.value
                        Toast.makeText(requireContext(), "4 image", Toast.LENGTH_SHORT).show()

                        Glide.with(this).load(about).transform(RotateTransformation(90f))
                            .into(binding.fullImage)
                    }

            "image5" ->
                database.child("ages").child("11-14").child("tyb").child("steps").child("1")
                    .child("1 week").child("1 task").child("1 image").get().addOnSuccessListener {
                        val about = it.value
                        Toast.makeText(requireContext(), "5 image", Toast.LENGTH_SHORT).show()

                        Glide.with(this).load(about).transform(RotateTransformation(90f))
                            .into(binding.fullImage)
                    }

            "image6" ->
                database.child("ages").child("11-14").child("tyb").child("steps").child("1")
                    .child("1 week").child("1 task").child("2 image").get().addOnSuccessListener {
                        val about = it.value
                        Toast.makeText(requireContext(), "6 image", Toast.LENGTH_SHORT).show()

                        Glide.with(this).load(about).transform(RotateTransformation(90f))
                            .into(binding.fullImage)
                    }

            "image7" ->
                database.child("ages").child("15-18").child("tyb").child("steps").child("1")
                    .child("1 week").child("1 task").child("1 image").get().addOnSuccessListener {
                        val about = it.value
                        Toast.makeText(requireContext(), "7 image", Toast.LENGTH_SHORT).show()

                        Glide.with(this).load(about).transform(RotateTransformation(90f))
                            .into(binding.fullImage)
                    }

            "image8" ->
                database.child("ages").child("15-18").child("tyb").child("steps").child("1")
                    .child("1 week").child("1 task").child("2 image").get().addOnSuccessListener {
                        val about = it.value
                        Toast.makeText(requireContext(), "8 image", Toast.LENGTH_SHORT).show()

                        Glide.with(this).load(about).transform(RotateTransformation(90f))
                            .into(binding.fullImage)
                    }


        }


        return view
    }


}
