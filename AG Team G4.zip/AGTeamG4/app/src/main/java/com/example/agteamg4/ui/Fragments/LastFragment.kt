package com.example.agteamg4.ui.Fragments

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ActivityNotFoundException
import android.content.Context.NOTIFICATION_SERVICE
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Parcelable
import android.provider.Settings
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat.getSystemService
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.example.agteamg4.R
import com.example.agteamg4.databinding.FragmentLastBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.channels.Channel


class LastFragment : Fragment() {
    lateinit var binding: FragmentLastBinding

    lateinit var firebaseAuth: FirebaseAuth

    var image1: String? = null
    var image2: String? = null
    var image3: String? = null
    var image4: String? = null
    var image5: String? = null
    var image6: String? = null
    var image7: String? = null
    var image8: String? = null


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {


        val view = inflater.inflate(R.layout.fragment_last, container, false)
        binding = FragmentLastBinding.bind(view)

        val week1 = arguments?.getBoolean("week1")
        val week2 = arguments?.getBoolean("week2")
        val week3 = arguments?.getBoolean("week3")
        val week4 = arguments?.getBoolean("week4")
        val week5 = arguments?.getBoolean("week5")
        val week6 = arguments?.getBoolean("week6")
        val week7 = arguments?.getBoolean("week7")
        val week8 = arguments?.getBoolean("week8")


        if (week1 == true) {
            readItemData1()
        }
        if (week2 == true) {
            readItemData2()
        }
        if (week3 == true) {
            readItemData3()
        }
        if (week4 == true) {
            readItemData4()
        }
        if (week5 == true) {
            readItemData5()
        }
        if (week6 == true) {
            readItemData6()
        }
        if (week7 == true) {
            readItemData7()
        }
        if (week8 == true) {
            readItemData8()
        }







        return view
    }

    fun readItemData1() {
        firebaseAuth = FirebaseAuth.getInstance()
        val currentUser = firebaseAuth.currentUser

        val database = Firebase.database.reference



        database.child("users").child(currentUser!!.uid).child("age").get()
            .addOnSuccessListener { it1 ->
                val about = it1.value
                if (about.toString().toInt() <= 5) {

                    binding.gameBtn.visibility = View.VISIBLE


                    binding.gameBtn.setOnClickListener {
                        val webIntent = Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("https://chrislee0326.github.io/AGgame/cardgame.html")
                        )
                        try {
                            startActivity(webIntent)
                        } catch (e: ActivityNotFoundException) {
                            Toast.makeText(
                                requireContext(),
                                "No Activity",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }

                    binding.gameBtn.setOnClickListener {
                        val webIntent = Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("https://chrislee0326.github.io/AGgame/cardgame.html")
                        )
                        try {
                            startActivity(webIntent)
                        } catch (e: ActivityNotFoundException) {
                            Toast.makeText(
                                requireContext(),
                                "No Activity",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }

                    database.child("ages").child("0-5").child("tyb").child("steps").child("1")
                        .child("1 week").child("video_link").get()
                        .addOnSuccessListener {
                            Log.i("firebase", "Got value ${it.value}")
                            val about = it.value

                            binding.watchHere.setOnClickListener {

                                binding.videoView.setVideoPath(about.toString())
                                val mediaController = android.widget.MediaController(context)
                                mediaController.setAnchorView(binding.videoView)
                                binding.videoView.setMediaController(mediaController)
                                binding.videoView.start()
                            }


                        }.addOnFailureListener {
                            Toast.makeText(
                                requireContext(),
                                "This task has already been completed",
                                Toast.LENGTH_SHORT
                            )
                                .show()
                            Log.e("firebase", "Error getting data", it)
                        }

                    binding.ytbLink.setOnClickListener {
                        database.child("ages").child("0-5").child("tyb").child("steps").child("1")
                            .child("1 week").child("youtube_link").get()
                            .addOnSuccessListener {
                                Log.i("firebase", "Got value ${it.value}")
                                val about = it.value

                                val webIntent: Intent = Intent(
                                    Intent.ACTION_VIEW, Uri.parse(about.toString())
                                )
                                try {
                                    startActivity(webIntent)
                                } catch (e: ActivityNotFoundException) {
                                    Toast.makeText(
                                        requireContext(),
                                        "No Activity",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }

                            }.addOnFailureListener {
                                Log.e("firebase", "Error getting data", it)
                            }

                    }

                    database.child("ages").child("0-5").child("tyb").child("steps").child("1")
                        .child("1 week").child("1 task").child("1 image").get()
                        .addOnSuccessListener {
                            Log.i("firebase", "Got value ${it.value}")
                            val about = it.value
                            Glide.with(this).load(about).into(binding.image1)


                            binding.card1.setOnClickListener {
                                image1 = "image1"
                                val bundle = Bundle().apply {
                                    putString("image", image1)
                                }
                                findNavController().navigate(
                                    R.id.action_lastFragment_to_imageFragment,
                                    bundle
                                )
                            }

                        }.addOnFailureListener {
                            Log.e("firebase", "Error getting data", it)
                        }

                    database.child("ages").child("0-5").child("tyb").child("steps").child("1")
                        .child("1 week").child("1 task").child("2 image").get()
                        .addOnSuccessListener {
                            Log.i("firebase", "Got value ${it.value}")
                            val about = it.value

                            Glide.with(this).load(about).into(binding.image2)

                            binding.card2.setOnClickListener {
                                image2 = "image2"
                                val bundle = Bundle().apply {
                                    putString("image", image2)
                                }
                                findNavController().navigate(
                                    R.id.action_lastFragment_to_imageFragment,
                                    bundle
                                )
                            }

                        }.addOnFailureListener {
                            Log.e("firebase", "Error getting data", it)
                        }


                    binding.finishBtn.setOnClickListener {


                        findNavController().popBackStack()


                    }

                } else if (about.toString().toInt() in 6..10) {
                    database.child("ages").child("6-10").child("tyb").child("steps")
                        .child("1")
                        .child("1 week").child("video_link").get()
                        .addOnSuccessListener {
                            Log.i("firebase", "Got value ${it.value}")
                            val about = it.value

                            binding.watchHere.setOnClickListener {

                                binding.videoView.setVideoPath(about.toString())
                                val mediaController = android.widget.MediaController(context)
                                mediaController.setAnchorView(binding.videoView)
                                binding.videoView.setMediaController(mediaController)
                                binding.videoView.start()
                            }


                        }.addOnFailureListener {
                            Toast.makeText(
                                requireContext(),
                                "This task has already been completed",
                                Toast.LENGTH_SHORT
                            )
                                .show()
                            Log.e("firebase", "Error getting data", it)
                        }

                    binding.ytbLink.setOnClickListener {
                        database.child("ages").child("6-10").child("tyb")
                            .child("steps").child("1")
                            .child("1 week").child("youtube_link").get()
                            .addOnSuccessListener {
                                Log.i("firebase", "Got value ${it.value}")
                                val about = it.value

                                val webIntent: Intent = Intent(
                                    Intent.ACTION_VIEW,
                                    Uri.parse(about.toString())
                                )
                                try {
                                    startActivity(webIntent)
                                } catch (e: ActivityNotFoundException) {
                                    Toast.makeText(
                                        requireContext(),
                                        "No Activity",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }

                            }.addOnFailureListener {
                                Log.e("firebase", "Error getting data", it)
                            }

                    }

                    database.child("ages").child("6-10").child("tyb").child("steps")
                        .child("1")
                        .child("1 week").child("1 task").child("1 image").get()
                        .addOnSuccessListener {
                            Log.i("firebase", "Got value ${it.value}")
                            val about = it.value
                            Glide.with(this).load(about).into(binding.image1)


                            binding.card1.setOnClickListener {
                                image3 = "image3"
                                val bundle = Bundle().apply {
                                    putString("image", image3)
                                }
                                findNavController().navigate(
                                    R.id.action_lastFragment_to_imageFragment,
                                    bundle
                                )
                            }

                        }.addOnFailureListener {
                            Log.e("firebase", "Error getting data", it)
                        }

                    database.child("ages").child("6-10").child("tyb").child("steps")
                        .child("1")
                        .child("1 week").child("1 task").child("2 image").get()
                        .addOnSuccessListener {
                            Log.i("firebase", "Got value ${it.value}")
                            val about = it.value

                            Glide.with(this).load(about).into(binding.image2)

                            binding.card2.setOnClickListener {
                                image4 = "image4"
                                val bundle = Bundle().apply {
                                    putString("image", image4)
                                }
                                findNavController().navigate(
                                    R.id.action_lastFragment_to_imageFragment,
                                    bundle
                                )
                            }

                        }.addOnFailureListener {
                            Log.e("firebase", "Error getting data", it)
                        }


                    binding.finishBtn.setOnClickListener {

                        findNavController().popBackStack()


                    }
                } else if (about.toString().toInt() in 11..14) {
                    database.child("ages").child("11-14").child("tyb").child("steps").child("1")
                        .child("1 week").child("video_link").get()
                        .addOnSuccessListener {
                            Log.i("firebase", "Got value ${it.value}")


                            val about = it.value

                            binding.watchHere.setOnClickListener {

                                binding.videoView.setVideoPath(about.toString())
                                val mediaController = android.widget.MediaController(context)
                                mediaController.setAnchorView(binding.videoView)
                                binding.videoView.setMediaController(mediaController)
                                binding.videoView.start()
                            }


                        }.addOnFailureListener {
                            Toast.makeText(
                                requireContext(),
                                "This task has already been completed",
                                Toast.LENGTH_SHORT
                            )
                                .show()
                            Log.e("firebase", "Error getting data", it)
                        }

                    binding.ytbLink.setOnClickListener {
                        database.child("ages").child("11-14").child("tyb").child("steps").child("1")
                            .child("1 week").child("youtube_link").get()
                            .addOnSuccessListener {
                                Log.i("firebase", "Got value ${it.value}")
                                val about = it.value

                                val webIntent: Intent = Intent(
                                    Intent.ACTION_VIEW,
                                    Uri.parse(about.toString())
                                )
                                try {
                                    startActivity(webIntent)
                                } catch (e: ActivityNotFoundException) {
                                    Toast.makeText(
                                        requireContext(),
                                        "No Activity",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }

                            }.addOnFailureListener {
                                Log.e("firebase", "Error getting data", it)
                            }

                    }

                    database.child("ages").child("11-14").child("tyb").child("steps").child("1")
                        .child("1 week").child("1 task").child("1 image").get()
                        .addOnSuccessListener {
                            Log.i("firebase", "Got value ${it.value}")
                            val about = it.value
                            Glide.with(this).load(about).into(binding.image1)


                            binding.card1.setOnClickListener {
                                image5 = "image5"
                                val bundle = Bundle().apply {
                                    putString("image", image5)
                                }
                                findNavController().navigate(
                                    R.id.action_lastFragment_to_imageFragment,
                                    bundle
                                )
                            }

                        }.addOnFailureListener {
                            Log.e("firebase", "Error getting data", it)
                        }

                    database.child("ages").child("11-14").child("tyb").child("steps").child("1")
                        .child("1 week").child("1 task").child("2 image").get()
                        .addOnSuccessListener {
                            Log.i("firebase", "Got value ${it.value}")
                            val about = it.value

                            Glide.with(this).load(about).into(binding.image2)

                            binding.card2.setOnClickListener {
                                image6 = "image6"
                                val bundle = Bundle().apply {
                                    putString("image", image6)
                                }
                                findNavController().navigate(
                                    R.id.action_lastFragment_to_imageFragment,
                                    bundle
                                )
                            }

                        }.addOnFailureListener {
                            Log.e("firebase", "Error getting data", it)
                        }





                    binding.finishBtn.setOnClickListener {

                        findNavController().popBackStack()


                    }
                } else if (about.toString().toInt() in 15..99) {
                    database.child("ages").child("15-18").child("tyb").child("steps").child("1")
                        .child("1 week").child("video_link").get()
                        .addOnSuccessListener {
                            Log.i("firebase", "Got value ${it.value}")


                            val about = it.value

                            binding.watchHere.setOnClickListener {
                                binding.videoView.setVideoPath(about.toString())
                                val mediaController = android.widget.MediaController(context)
                                mediaController.setAnchorView(binding.videoView)
                                binding.videoView.setMediaController(mediaController)
                                binding.videoView.start()
                            }


                        }.addOnFailureListener {
                            Toast.makeText(
                                requireContext(),
                                "This task has already been completed",
                                Toast.LENGTH_SHORT
                            )
                                .show()
                            Log.e("firebase", "Error getting data", it)
                        }

                    binding.ytbLink.setOnClickListener {
                        database.child("ages").child("15-18").child("tyb").child("steps").child("1")
                            .child("1 week").child("youtube_link").get()
                            .addOnSuccessListener {
                                Log.i("firebase", "Got value ${it.value}")
                                val about = it.value

                                val webIntent: Intent = Intent(
                                    Intent.ACTION_VIEW,
                                    Uri.parse(about.toString())
                                )
                                try {
                                    startActivity(webIntent)
                                } catch (e: ActivityNotFoundException) {
                                    Toast.makeText(
                                        requireContext(),
                                        "No Activity",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }

                            }.addOnFailureListener {
                                Log.e("firebase", "Error getting data", it)
                            }

                    }

                    database.child("ages").child("15-18").child("tyb").child("steps").child("1")
                        .child("1 week").child("1 task").child("1 image").get()
                        .addOnSuccessListener {
                            Log.i("firebase", "Got value ${it.value}")
                            val about = it.value
                            Glide.with(this).load(about).into(binding.image1)


                            binding.card1.setOnClickListener {
                                image7 = "image7"
                                val bundle = Bundle().apply {
                                    putString("image", image7)
                                }
                                findNavController().navigate(
                                    R.id.action_lastFragment_to_imageFragment,
                                    bundle
                                )
                            }

                        }.addOnFailureListener {
                            Log.e("firebase", "Error getting data", it)
                        }

                    database.child("ages").child("15-18").child("tyb").child("steps").child("1")
                        .child("1 week").child("1 task").child("2 image").get()
                        .addOnSuccessListener {
                            Log.i("firebase", "Got value ${it.value}")
                            val about = it.value

                            Glide.with(this).load(about).into(binding.image2)

                            binding.card2.setOnClickListener {
                                image8 = "image8"
                                val bundle = Bundle().apply {
                                    putString("image", image8)
                                }
                                findNavController().navigate(
                                    R.id.action_lastFragment_to_imageFragment,
                                    bundle
                                )
                            }

                        }.addOnFailureListener {
                            Log.e("firebase", "Error getting data", it)
                        }





                    binding.finishBtn.setOnClickListener {

                        findNavController().popBackStack()


                    }

                }
            }


    }

    fun readItemData2() {
        firebaseAuth = FirebaseAuth.getInstance()
        val currentUser = firebaseAuth.currentUser
        val database = Firebase.database.reference

        database.child("tasks").child("tyb").child("steps").child("1")
            .child("2 week").child("video_link").get()
            .addOnSuccessListener {
                Log.i("firebase", "Got value ${it.value}")
                val about = it.value

                binding.videoView.setVideoPath(about.toString())

                val mediaController = android.widget.MediaController(context)
                mediaController.setAnchorView(binding.videoView)
                binding.videoView.setMediaController(mediaController)
                binding.videoView.start()


            }.addOnFailureListener {
                Toast.makeText(
                    requireContext(),
                    "This task has already been completed",
                    Toast.LENGTH_SHORT
                )
                    .show()
                Log.e("firebase", "Error getting data", it)
            }

        binding.finishBtn.setOnClickListener {

            database.child("users").child(currentUser!!.uid).child("tasks").child("tyb")
                .child("2 week").setValue("true")
            findNavController().popBackStack()


        }

    }

    fun readItemData3() {
        firebaseAuth = FirebaseAuth.getInstance()
        val currentUser = firebaseAuth.currentUser
        val database = Firebase.database.reference

        binding.finishBtn.setOnClickListener {

            database.child("users").child(currentUser!!.uid).child("tasks").child("cm")
                .child("1 week").setValue("true")
            findNavController().popBackStack()
        }
    }

    fun readItemData4() {
        firebaseAuth = FirebaseAuth.getInstance()
        val currentUser = firebaseAuth.currentUser
        val database = Firebase.database.reference
        binding.finishBtn.setOnClickListener {

            database.child("users").child(currentUser!!.uid).child("tasks").child("cm")
                .child("2 week").setValue("true")
            findNavController().popBackStack()
        }

    }

    fun readItemData5() {
        firebaseAuth = FirebaseAuth.getInstance()
        val currentUser = firebaseAuth.currentUser
        val database = Firebase.database.reference
        binding.finishBtn.setOnClickListener {
            database.child("users").child(currentUser!!.uid).child("tasks").child("english")
                .child("1 week").setValue("true")
            findNavController().popBackStack()
        }


    }

    fun readItemData6() {
        firebaseAuth = FirebaseAuth.getInstance()
        val currentUser = firebaseAuth.currentUser
        val database = Firebase.database.reference
        binding.finishBtn.setOnClickListener {
            database.child("users").child(currentUser!!.uid).child("tasks").child("english")
                .child("2 week").setValue("true")
            findNavController().popBackStack()
        }
    }

    fun readItemData7() {
        firebaseAuth = FirebaseAuth.getInstance()
        val currentUser = firebaseAuth.currentUser

        val database = Firebase.database.reference

        database.child("tasks").child("mathematics").child("steps").child("1")
            .child("1 week").child("video_link").get()
            .addOnSuccessListener {
                Log.i("firebase", "Got value ${it.value}")
                val about = it.value
                binding.videoView.setVideoPath(about.toString())
                binding.videoView.start()

            }.addOnFailureListener {
                Log.e("firebase", "Error getting data", it)
            }
        binding.finishBtn.setOnClickListener {
            database.child("users").child(currentUser!!.uid).child("tasks").child("mathematics")
                .child("1 week").setValue("true")
            findNavController().popBackStack()
        }
    }

    fun readItemData8() {
        val database = Firebase.database.reference

        firebaseAuth = FirebaseAuth.getInstance()
        val currentUser = firebaseAuth.currentUser
        database.child("tasks").child("mathematics").child("steps").child("1")
            .child("2 week").child("video_link").get()
            .addOnSuccessListener {
                Log.i("firebase", "Got value ${it.value}")
                val about = it.value

                binding.videoView.setVideoPath(about.toString())
                binding.videoView.start()


            }.addOnFailureListener {
                Log.e("firebase", "Error getting data", it)
            }
        binding.finishBtn.setOnClickListener {
            database.child("users").child(currentUser!!.uid).child("tasks").child("mathematics")
                .child("2 week").setValue("true")
            findNavController().popBackStack()
        }

    }
}