package com.example.agteamg4.ui.Registration

import android.app.NotificationManager
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.example.agteamg4.Data.Users
import com.example.agteamg4.MainActivity
import com.example.agteamg4.databinding.ActivityReg2Binding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class Reg2Activity : AppCompatActivity() {

    lateinit var firebaseAuth: FirebaseAuth
    lateinit var firebaseDatabase: FirebaseDatabase
    lateinit var reference: DatabaseReference


    lateinit var binding: ActivityReg2Binding
    override fun onCreate(savedInstanceState: Bundle?) {

        binding = ActivityReg2Binding.inflate(layoutInflater)

        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()
        val currenUser = firebaseAuth.currentUser

        firebaseDatabase = FirebaseDatabase.getInstance()
        reference = firebaseDatabase.getReference("users")

        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)


        val roleList = listOf( "Male", "Female", "Prefer not to tell")
        val adapter = ArrayAdapter<String>(
            this,
            androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,
            roleList
        )
        binding.spinner1.adapter = adapter

        val genderList = listOf( "Student", "Teacher", "Parent")
        val adapter2 = ArrayAdapter<String>(
            this,
            androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,
            genderList
        )
        binding.spinner2.adapter = adapter2




        binding.page3Nextbtn.setOnClickListener {
            val nickname = binding.nicknameTx.text.toString()
            val age = binding.ageTx.text.toString()
            val number = intent.getStringExtra("number")

            val roleType = binding.spinner2.selectedItem.toString()
            val genderType = binding.spinner1.selectedItem.toString()
            val uid = "1"
            val user = Users(uid, nickname, age, number, genderType, roleType)



            if (nickname.isNotBlank()) {
                reference.child("1").setValue(user)
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this, "Nickname is empty", Toast.LENGTH_SHORT).show()
            }


        }


    }
}