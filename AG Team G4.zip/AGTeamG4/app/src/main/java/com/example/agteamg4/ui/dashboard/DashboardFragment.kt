package com.example.agteamg4.ui.dashboard

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.example.agteamg4.databinding.FragmentDashboardBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    private val database = Firebase.database.reference


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {


        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        val root: View = binding.root

        database.child("e_library").child("update_date").get().addOnSuccessListener {
            Log.i("firebase", "Got value ${it.value}")

            val about = it.value
            binding.update.text = about.toString()

        }



        book1()
        book2()
        book3()
        book4()
        book5()










        return root
    }

    private fun book1() {
        database.child("e_library").child("1").child("theme").get().addOnSuccessListener {
            Log.i("firebase", "Got value ${it.value}")

            val theme1 = it.value.toString()

            binding.book1Theme.text = theme1


        }

        database.child("e_library").child("1").child("author").get().addOnSuccessListener {
            Log.i("firebase", "Got value ${it.value}")

            val author1 = it.value.toString()

            binding.book1Author.text = author1


        }

        database.child("e_library").child("1").child("genre").get().addOnSuccessListener {
            Log.i("firebase", "Got value ${it.value}")

            val genre1 = it.value.toString()

            binding.book1Genre.text = genre1


        }
        database.child("e_library").child("1").child("photo_link").get().addOnSuccessListener {
            Log.i("firebase", "Got value ${it.value}")

            val photo_link = it.value.toString()

            Glide.with(this).load(photo_link).into(binding.image1)


        }

        binding.book1.setOnClickListener {
            database.child("e_library").child("1").child("link").get()
                .addOnSuccessListener {
                    Log.i("firebase", "Got value ${it.value}")
                    val about = it.value

                    val webIntent: Intent = Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse(about.toString())
                    )
                    try {
                        startActivity(webIntent)
                    } catch (e: ActivityNotFoundException) {
                        Toast.makeText(requireContext(), "No Activity", Toast.LENGTH_SHORT).show()
                    }
                }
        }


    }

    private fun book2() {
        database.child("e_library").child("2").child("theme").get().addOnSuccessListener {
            Log.i("firebase", "Got value ${it.value}")

            val theme2 = it.value.toString()

            binding.book2Theme.text = theme2


        }
        database.child("e_library").child("2").child("photo_link").get().addOnSuccessListener {
            Log.i("firebase", "Got value ${it.value}")

            val photo_link = it.value.toString()

            Glide.with(this).load(photo_link).into(binding.image2)


        }
        database.child("e_library").child("2").child("genre").get().addOnSuccessListener {
            Log.i("firebase", "Got value ${it.value}")

            val genre2 = it.value.toString()

            binding.book2Genre.text = genre2


        }

        database.child("e_library").child("2").child("author").get().addOnSuccessListener {
            Log.i("firebase", "Got value ${it.value}")

            val theme2 = it.value.toString()

            binding.book2Author.text = theme2


        }

        binding.book2.setOnClickListener {
            database.child("e_library").child("2").child("link").get()
                .addOnSuccessListener {
                    Log.i("firebase", "Got value ${it.value}")
                    val about = it.value

                    val webIntent: Intent = Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse(about.toString())
                    )
                    try {
                        startActivity(webIntent)
                    } catch (e: ActivityNotFoundException) {
                        Toast.makeText(requireContext(), "No Activity", Toast.LENGTH_SHORT).show()
                    }
                }
        }
    }

    private fun book3() {
        database.child("e_library").child("3").child("theme").get().addOnSuccessListener {
            Log.i("firebase", "Got value ${it.value}")

            val theme3 = it.value.toString()

            binding.book3Theme.text = theme3


        }
        database.child("e_library").child("3").child("photo_link").get().addOnSuccessListener {
            Log.i("firebase", "Got value ${it.value}")

            val photo_link = it.value.toString()

            Glide.with(this).load(photo_link).into(binding.image3)


        }
        database.child("e_library").child("3").child("genre").get().addOnSuccessListener {
            Log.i("firebase", "Got value ${it.value}")

            val genre3 = it.value.toString()

            binding.book3Genre.text = genre3


        }

        database.child("e_library").child("3").child("author").get().addOnSuccessListener {
            Log.i("firebase", "Got value ${it.value}")

            val author3 = it.value.toString()

            binding.book3Author.text = author3


        }
        binding.book3.setOnClickListener {
            database.child("e_library").child("3").child("link").get()
                .addOnSuccessListener {
                    Log.i("firebase", "Got value ${it.value}")
                    val about = it.value

                    val webIntent: Intent = Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse(about.toString())
                    )
                    try {
                        startActivity(webIntent)
                    } catch (e: ActivityNotFoundException) {
                        Toast.makeText(requireContext(), "No Activity", Toast.LENGTH_SHORT).show()
                    }
                }
        }
    }

    private fun book4() {
        database.child("e_library").child("4").child("theme").get().addOnSuccessListener {
            Log.i("firebase", "Got value ${it.value}")

            val theme4 = it.value.toString()

            binding.book4Theme.text = theme4


        }

        database.child("e_library").child("4").child("author").get().addOnSuccessListener {
            Log.i("firebase", "Got value ${it.value}")

            val author4 = it.value.toString()

            binding.book4Author.text = author4


        }
        database.child("e_library").child("4").child("photo_link").get().addOnSuccessListener {
            Log.i("firebase", "Got value ${it.value}")

            val photo_link2 = it.value.toString()

            Glide.with(this).load(photo_link2).into(binding.image4)


        }
        database.child("e_library").child("4").child("genre").get().addOnSuccessListener {
            Log.i("firebase", "Got value ${it.value}")

            val genre4 = it.value.toString()

            binding.book4Genre.text = genre4


        }
    }
    private fun book5() {
        database.child("e_library").child("5").child("theme").get().addOnSuccessListener {
            Log.i("firebase", "Got value ${it.value}")

            val theme5 = it.value.toString()

            binding.book5Theme.text = theme5


        }

        database.child("e_library").child("5").child("author").get().addOnSuccessListener {
            Log.i("firebase", "Got value ${it.value}")

            val author5 = it.value.toString()

            binding.book5Author.text = author5


        }
        database.child("e_library").child("5").child("photo_link").get().addOnSuccessListener {
            Log.i("firebase", "Got value ${it.value}")

            val photo_link3 = it.value.toString()

            Glide.with(this).load(photo_link3).into(binding.image5)


        }
        database.child("e_library").child("5").child("genre").get().addOnSuccessListener {
            Log.i("firebase", "Got value ${it.value}")

            val genre5 = it.value.toString()

            binding.book5Genre.text = genre5


        }
        binding.book5.setOnClickListener {
            database.child("e_library").child("5").child("link").get()
                .addOnSuccessListener {
                    Log.i("firebase", "Got value ${it.value}")
                    val about = it.value

                    val webIntent: Intent = Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse(about.toString())
                    )
                    try {
                        startActivity(webIntent)
                    } catch (e: ActivityNotFoundException) {
                        Toast.makeText(requireContext(), "No Activity", Toast.LENGTH_SHORT).show()
                    }
                }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}