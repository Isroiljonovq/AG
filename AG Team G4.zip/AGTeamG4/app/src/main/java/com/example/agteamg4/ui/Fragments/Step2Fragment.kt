package com.example.agteamg4.ui.Fragments

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.example.agteamg4.R
import com.example.agteamg4.databinding.FragmentStep2Binding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase


class Step2Fragment : Fragment() {


    var week1 = false
    var week2 = false
    var week3 = false
    var week4 = false
    var week5 = false
    var week6 = false
    var week7 = false
    var week8 = false


    lateinit var binding: FragmentStep2Binding
    lateinit var firebaseAuth: FirebaseAuth

    lateinit var firebaseDatabase: FirebaseDatabase
    lateinit var reference: DatabaseReference
    val database = Firebase.database.reference


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_step2, container, false)
        binding = FragmentStep2Binding.bind(view)


        val card1_step1 = arguments?.getBoolean("step1")
        val card2_step1 = arguments?.getBoolean("step2")
        val card3_step1 = arguments?.getBoolean("step3")
        val card4_step1 = arguments?.getBoolean("step4")
        val gender = arguments?.getBoolean("gender")


        if (card1_step1 == true) {
            readItemData1()
        }
        if (card2_step1 == true) {
            readItemData2()
        }
        if (card3_step1 == true) {
            readItemData3()
        }
        if (card4_step1 == true) {
            readItemData4()
        }
        if (gender == true) {
            binding.stepBackground.setBackgroundResource(R.drawable.tlb_background)

        }

        return view
    }

    fun readItemData1() {
        firebaseAuth = FirebaseAuth.getInstance()
        val currentUser = firebaseAuth.currentUser




        binding.week1.setOnClickListener {

            database.child("users").child("1").child("tasks").child("tyb")
                .child("1 week").get()
                .addOnSuccessListener {
                    val about = it.value
                    if (about == "true") {

                        Toast.makeText(
                            requireContext(),
                            "This task has already been completed",
                            Toast.LENGTH_SHORT
                        )
                            .show()

                    } else {
                        week1 = true
                        val bundle = Bundle().apply {
                            putBoolean("week1", week1)
                        }
                        findNavController().navigate(
                            R.id.action_step2Fragment_to_lastFragment,
                            bundle
                        )
                    }
                }


        }
        binding.week2.setOnClickListener() {
            database.child("users").child("1").child("tasks").child("tyb")
                .child("2 week").get()
                .addOnSuccessListener {
                    val about = it.value
                    if (about == "true") {

                        Toast.makeText(
                            requireContext(),
                            "This task has already been completed",
                            Toast.LENGTH_SHORT
                        )
                            .show()

                    } else {
                        week2 = true
                        var bundle = Bundle().apply {
                            putBoolean("week2", week2)
                        }
                        findNavController().navigate(
                            R.id.action_step2Fragment_to_lastFragment,
                            bundle
                        )
                    }
                }
        }

    }

    fun readItemData2() {

        firebaseAuth = FirebaseAuth.getInstance()
        val currentUser = firebaseAuth.currentUser


        binding.week1.setOnClickListener() {
            database.child("users").child("1").child("tasks").child("cm")
                .child("1 week").get()
                .addOnSuccessListener {
                    val about = it.value
                    if (about == "true") {

                        Toast.makeText(
                            requireContext(),
                            "This task has already been completed",
                            Toast.LENGTH_SHORT
                        )
                            .show()

                    } else {
                        week3 = true
                        var bundle = Bundle().apply {
                            putBoolean("week3", week3)
                        }
                        findNavController().navigate(
                            R.id.action_step2Fragment_to_lastFragment,
                            bundle
                        )
                    }
                }
        }
        binding.week2.setOnClickListener() {
            database.child("users").child("1").child("tasks").child("cm")
                .child("2 week").get()
                .addOnSuccessListener {
                    val about = it.value
                    if (about == "true") {

                        Toast.makeText(
                            requireContext(),
                            "This task has already been completed",
                            Toast.LENGTH_SHORT
                        )
                            .show()

                    } else {
                        week4 = true
                        var bundle = Bundle().apply {
                            putBoolean("week4", week4)
                        }
                        findNavController().navigate(
                            R.id.action_step2Fragment_to_lastFragment,
                            bundle
                        )
                    }
                }
        }

    }

    fun readItemData3() {

        firebaseAuth = FirebaseAuth.getInstance()
        val currentUser = firebaseAuth.currentUser


        binding.week1.setOnClickListener {
            database.child("users").child("1").child("tasks").child("english")
                .child("1 week").get()
                .addOnSuccessListener {
                    val about = it.value
                    if (about == "true") {

                        Toast.makeText(
                            requireContext(),
                            "This task has already been completed",
                            Toast.LENGTH_SHORT
                        )
                            .show()

                    } else {
                        week5 = true
                        var bundle = Bundle().apply {
                            putBoolean("week5", week5)
                        }
                        findNavController().navigate(
                            R.id.action_step2Fragment_to_lastFragment,
                            bundle
                        )
                    }
                }
        }
        binding.week2.setOnClickListener() {
            database.child("users").child("1").child("tasks").child("english")
                .child("2 week").get()
                .addOnSuccessListener {
                    val about = it.value
                    if (about == "true") {

                        Toast.makeText(
                            requireContext(),
                            "This task has already been completed",
                            Toast.LENGTH_SHORT
                        )
                            .show()

                    } else {
                        week6 = true
                        var bundle = Bundle().apply {
                            putBoolean("week6", week6)
                        }
                        findNavController().navigate(
                            R.id.action_step2Fragment_to_lastFragment,
                            bundle
                        )
                    }
                }
        }

    }

    fun readItemData4() {

        firebaseAuth = FirebaseAuth.getInstance()
        val currentUser = firebaseAuth.currentUser

        binding.week1.setOnClickListener {
            database.child("users").child("1").child("tasks").child("mathematics")
                .child("1 week").get()
                .addOnSuccessListener {
                    val about = it.value
                    if (about == "true") {

                        Toast.makeText(
                            requireContext(),
                            "This task has already been completed",
                            Toast.LENGTH_SHORT
                        )
                            .show()

                    } else {
                        week7 = true
                        var bundle = Bundle().apply {
                            putBoolean("week7", week7)
                        }
                        findNavController().navigate(
                            R.id.action_step2Fragment_to_lastFragment,
                            bundle
                        )
                    }
                }
        }
        binding.week2.setOnClickListener() {

            firebaseAuth = FirebaseAuth.getInstance()
            val currentUser = firebaseAuth.currentUser

            database.child("users").child("1").child("tasks").child("mathematics")
                .child("2 week").get()
                .addOnSuccessListener {
                    val about = it.value
                    if (about == "true") {

                        Toast.makeText(
                            requireContext(),
                            "This task has already been completed",
                            Toast.LENGTH_SHORT
                        )
                            .show()

                    } else {
                        week8 = true
                        var bundle = Bundle().apply {
                            putBoolean("week8", week8)
                        }
                        findNavController().navigate(
                            R.id.action_step2Fragment_to_lastFragment,
                            bundle
                        )
                    }
                }
        }

    }


}