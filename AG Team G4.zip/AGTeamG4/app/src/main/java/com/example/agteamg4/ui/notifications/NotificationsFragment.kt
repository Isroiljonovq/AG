package com.example.agteamg4.ui.notifications

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.agteamg4.R
import com.example.agteamg4.databinding.FragmentNotificationsBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class NotificationsFragment : Fragment() {

    private var _binding: FragmentNotificationsBinding? = null
    private val binding get() = _binding!!
    lateinit var firebaseAuth: FirebaseAuth


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        firebaseAuth = FirebaseAuth.getInstance()

        _binding = FragmentNotificationsBinding.inflate(inflater, container, false)
        val root: View = binding.root

        readItemData1()

        return root
    }

    fun readItemData1() {


        binding.apply {
            tree2btn.setOnClickListener {
                if (tree1.visibility == View.VISIBLE) {
                    binding.tree1.visibility = View.INVISIBLE
                    binding.tree2.visibility = View.VISIBLE
                } else {
                    binding.tree1.visibility = View.VISIBLE
                    binding.tree2.visibility = View.INVISIBLE

                }
            }

        }

    }


}